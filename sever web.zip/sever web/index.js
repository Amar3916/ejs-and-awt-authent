const express = require("express");
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");

const app = express();
const port = 8222;

const JWT_SECRET = "my_super_secret_key_123!"; // Replace with your actual secret key
const JWT_EXPIRY = "1h";

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/practice")
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.error("Could not connect to MongoDB", err));

// Define User schema and model
const userSchema = new mongoose.Schema({
    fullname: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    profile: {
        phone: String,
        interests: String,
        bio: String
    }
});

const User = mongoose.model("User", userSchema);

// Middleware
app.use(express.static(path.join(__dirname, "views")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// JWT Authentication Middleware
const authenticateToken = (req, res, next) => {
    const token = req.headers.authorization && req.headers.authorization.split(" ")[1];
    if (!token) return res.status(401).json({ message: "Access denied" });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: "Invalid token" });
        req.userId = user.userId; // Set userId for later use
        next();
    });
};

// Routes
app.get(["/", "/home.html"], (req, res) => {
    res.sendFile(path.join(__dirname, "views", "home.html"));
});

app.route(["/register", "/register.html"])
    .get((req, res) => {
        res.sendFile(path.join(__dirname, "views", "register.html"));
    })
    .post(async (req, res) => {
        const { fullname, email, password } = req.body;
        const user = new User({ fullname, email, password });

        try {
            await user.save();
            res.send("Registration data saved successfully in MongoDB");
        } catch (error) {
            if (error.code === 11000) {
                res.status(400).send("Email already exists");
            } else {
                console.error("Error saving registration data:", error);
                res.status(500).send("Internal Server Error");
            }
        }
    });

app.route(["/login", "/login.html"])
    .get((req, res) => {
        res.sendFile(path.join(__dirname, "views", "login.html"));
    })
    .post(async (req, res) => {
        const { username: fullname, password } = req.body;

        try {
            const user = await User.findOne({ fullname, password });
            if (!user) return res.json({ success: false, message: "Invalid credentials" });

            // Generate JWT token
            const token = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: JWT_EXPIRY });

            console.log("Generated token:", token); // Log the token for debugging

            // Include redirect URL
            res.json({ success: true, token, redirectUrl: "/profile" });
        } catch (error) {
            console.error("Error during login:", error);
            res.status(500).json({ success: false, message: "Internal Server Error" });
        }
    });

// Static routes
app.get(["/search", "/search.html"], (req, res) => {
    res.sendFile(path.join(__dirname, "views", "search.html"));
});

app.get(["/course", "/courses.html"], (req, res) => {
    res.sendFile(path.join(__dirname, "views", "courses.html"));
});

app.get(["/plans", "/plans.html"], (req, res) => {
    res.sendFile(path.join(__dirname, "views", "plans.html"));
});

// Profile route (Protected)
app.get(["/profile", "/profile.html"], authenticateToken, async (req, res) => {
    try {
        const user = await User.findById(req.userId).select("fullname email profile");
        if (!user) {
            return res.status(404).send("User not found");
        }
        // Render profile.ejs and inject user data
        res.render("profile", { user });
    } catch (error) {
        console.error("Error fetching profile:", error);
        res.status(500).json({ message: "Error retrieving profile data" });
    }
});

// Profile update route (Protected)
app.post("/profile", authenticateToken, async (req, res) => {
    const { phone, interests, bio } = req.body;

    try {
        const user = await User.findByIdAndUpdate(
            req.userId,
            { profile: { phone, interests, bio } },
            { new: true }
        );
        res.json({ message: "Profile updated successfully", user });
    } catch (error) {
        console.error("Error updating profile:", error);
        res.status(500).json({ message: "Error updating profile" });
    }
});


// Logout Route
app.post("/logout", (req, res) => {
    res.json({ message: "Logged out successfully" });
});

// 404 handler
app.use((req, res) => {
    res.status(404).send("Page not found");
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
